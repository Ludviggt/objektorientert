#include "std_lib_facilities.h"
//constexpr char lower = 65; // plassen til A i ascii
//constexpr char upper = 71; // // plassen til F i ascii
void testCallByValue();
void testCallByReference();
void testswapValue();
void testString();